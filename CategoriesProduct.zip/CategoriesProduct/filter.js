/*function from search.js*/
SearchFunction();
noProduct();

/*function for left filter drop down list (to drop down the list)*/
function openSortList() {
  var x = document.getElementById("leftFilterSortBy");
  if (x.style.display === "none") {
    x.style.display = "inline-block";
  } else {
    x.style.display = "none";
  }
}

function openPriceList() {
  var x = document.getElementById("leftFilterPrice");
  if (x.style.display === "none") {
    x.style.display = "inline-block";
  } else {
    x.style.display = "none";
  }
}

/*function for left filter drop down list (invert icon)*/
function invertIcon(x) {
  x.childNodes[1].classList.toggle("fa-caret-up");
}

//checked for both smaller width filder radio and bigger width filter radio button while onclick
//and sorting function
$(document).ready(function () {
  //Sort By filter
  $(".rmd").click(function () {
    if ($("#mob_rmd").is(":checked")) {
      $("#rmd").prop("checked", true);

      var $sorted_items,
        getSorted = function (selector, attrName) {
          return $(
            $(selector)
              .toArray()
              .sort(function (a, b) {
                var aVal = parseInt(a.getAttribute(attrName)),
                  bVal = parseInt(b.getAttribute(attrName));
                return aVal - bVal;
              })
          );
        };
      $sorted_items = getSorted(".productListing .productItem", "data-order");
      $(".productListing").html($sorted_items);

      closeFilter();
    } else if ($("#rmd").is(":checked")) {
      $("#mob_rmd").prop("checked", true);

      var $sorted_items,
        getSorted = function (selector, attrName) {
          return $(
            $(selector)
              .toArray()
              .sort(function (a, b) {
                var aVal = parseInt(a.getAttribute(attrName)),
                  bVal = parseInt(b.getAttribute(attrName));
                return aVal - bVal;
              })
          );
        };
      $sorted_items = getSorted(".productListing .productItem", "data-order");
      $(".productListing").html($sorted_items);
    }
  });

  $(".lowestPrice").click(function () {
    if ($("#mob_lowestPrice").is(":checked")) {
      $("#lowestPrice").prop("checked", true);

      var $sorted_items,
        getSorted = function (selector, attrName) {
          return $(
            $(selector)
              .toArray()
              .sort(function (a, b) {
                var aVal = parseInt(a.getAttribute(attrName)),
                  bVal = parseInt(b.getAttribute(attrName));
                return aVal - bVal;
              })
          );
        };
      $sorted_items = getSorted(".productListing .productItem", "data-price");
      $(".productListing").html($sorted_items);

      closeFilter();
    } else if ($("#lowestPrice").is(":checked")) {
      $("#mob_lowestPrice").prop("checked", true);

      var $sorted_items,
        getSorted = function (selector, attrName) {
          return $(
            $(selector)
              .toArray()
              .sort(function (a, b) {
                var aVal = parseInt(a.getAttribute(attrName)),
                  bVal = parseInt(b.getAttribute(attrName));
                return aVal - bVal;
              })
          );
        };
      $sorted_items = getSorted(".productListing .productItem", "data-price");
      $(".productListing").html($sorted_items);
    }
  });

  $(".highestPrice").click(function () {
    if ($("#mob_highestPrice").is(":checked")) {
      $("#highestPrice").prop("checked", true);

      var $sorted_items,
        getSorted = function (selector, attrName) {
          return $(
            $(selector)
              .toArray()
              .sort(function (a, b) {
                var aVal = parseInt(a.getAttribute(attrName)),
                  bVal = parseInt(b.getAttribute(attrName));
                return bVal - aVal;
              })
          );
        };
      $sorted_items = getSorted(".productListing .productItem", "data-price");
      $(".productListing").html($sorted_items);

      closeFilter();
    } else if ($("#highestPrice").is(":checked")) {
      $("#mob_highestPrice").prop("checked", true);

      var $sorted_items,
        getSorted = function (selector, attrName) {
          return $(
            $(selector)
              .toArray()
              .sort(function (a, b) {
                var aVal = parseInt(a.getAttribute(attrName)),
                  bVal = parseInt(b.getAttribute(attrName));
                return bVal - aVal;
              })
          );
        };
      $sorted_items = getSorted(".productListing .productItem", "data-price");
      $(".productListing").html($sorted_items);
    }
  });

  //Price filter
  $(".below150").click(function () {
    if ($("#mob_below150").is(":checked")) {
      $("#below150").prop("checked", true);
      $(".productBelow150").show();
      $(".productBelow100").show();
      $(".productBelow50").show();
      SearchFunction();
      noProduct();
      closeFilter();
    } else if ($("#below150").is(":checked")) {
      $("#mob_below150").prop("checked", true);
      $(".productBelow150").show();
      $(".productBelow100").show();
      $(".productBelow50").show();
      SearchFunction();
      noProduct();
    }
  });
  $(".below100").click(function () {
    if ($("#mob_below100").is(":checked")) {
      $("#below100").prop("checked", true);
      $(".productBelow100").show();
      $(".productBelow50").show();
      SearchFunction();
      $(".productBelow150").hide();
      noProduct();
      closeFilter();
    } else if ($("#below100").is(":checked")) {
      $("#mob_below100").prop("checked", true);
      $(".productBelow100").show();
      $(".productBelow50").show();
      SearchFunction();
      $(".productBelow150").hide();
      noProduct();
    }
  });
  $(".below50").click(function () {
    if ($("#mob_below50").is(":checked")) {
      $("#below50").prop("checked", true);
      $(".productBelow50").show();
      SearchFunction();
      $(".productBelow150").hide();
      $(".productBelow100").hide();
      noProduct();
      closeFilter();
    } else if ($("#below50").is(":checked")) {
      $("#mob_below50").prop("checked", true);
      $(".productBelow50").show();
      SearchFunction();
      $(".productBelow150").hide();
      $(".productBelow100").hide();
      noProduct();
    }
  });
});

// open & close mobile left filter            <MOBILE>
function openFilter() {
  document.getElementById("mob_filter").style.width = "65%";
  document.getElementsByTagName("BODY")[0].style.overflow = "auto";
}

function closeFilter() {
  document.getElementById("mob_filter").style.width = "0%";
  document.getElementsByTagName("BODY")[0].style.overflow = "auto";
}

// drop down list for mobile left filter     <MOBILE>
function openMobSortList() {
  var x = document.getElementById("mob_leftFilterSortBy");
  if (x.style.display === "none") {
    x.style.display = "inline-block";
  } else {
    x.style.display = "none";
  }
}

function openMobPriceList() {
  var x = document.getElementById("mob_leftFilterPrice");
  if (x.style.display === "none") {
    x.style.display = "inline-block";
  } else {
    x.style.display = "none";
  }
}
